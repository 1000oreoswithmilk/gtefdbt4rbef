<?

$output = array(

       "valid" => 1,
       "domain" => "rebooters.online",

);

echo(json_encode($output, JSON_PRETTY_PRINT));
?>