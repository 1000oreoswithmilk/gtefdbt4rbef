<? include"../Header.php";?>
<div class="row">
<div class="col s12 m12 l8">
<div style="padding-top:50px;"></div>
<div class="container" style="width:100%;">
<div class="center-align">
<div style="padding-bottom:50px;">
<div class="text-center">
<script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
 
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5035877450680880" data-ad-slot="8645193052" data-ad-format="auto"></ins>
<script>
					(adsbygoogle = window.adsbygoogle || []).push({});
					</script>
</div>
</div>
</div>
<style>.hover{padding:25px 0;}.hover:hover{background:#fafafa;}a,a:active,a:hover{text-decoration:none;border:none;}</style>
<center>
<div class="bc-content">
<div style="font-size:45px;padding-top:25px;font-weight:200;padding-bottom:25px;color:#666;">What do you wish to create?</div>
<div class="row">
<a href="https://www.bloxcity.com/catalog/upload/tshirt">
<div class="col s4 text-center hover">
<img src="https://www.bloxcity.com/assets/images/t-shirt.png" style="margin:0 auto;">
<div style="font-size:35px;padding-top:25px;font-weight:200;color:#333;padding-bottom:25px;">T-Shirt</div>
</div>
</a>
<a href="https://www.bloxcity.com/catalog/upload/shirt">
<div class="col s4 text-center hover">
<img src="https://www.bloxcity.com/assets/images/shirt.png" style="margin:0 auto;">
<div style="font-size:35px;padding-top:25px;font-weight:200;color:#333;padding-bottom:25px;">Shirt</div>
</div>
</a>
<a href="https://www.bloxcity.com/catalog/upload/pants">
<div class="col s4 text-center hover">
<img src="https://www.bloxcity.com/assets/images/pants.png" style="margin:0 auto;">
<div style="font-size:35px;padding-top:25px;font-weight:200;color:#333;padding-bottom:25px;">Pants</div>
</div>
</a>
</div>
</div>
</center>
</div></div></div><br><br><br><br>
<?
include"../Footer.php";
?>