</div>
<div class="site-footer">
<div style="padding-top:15px;">
<div class="center-align">
<img src="https://storage.googleapis.com/bloxcity-file-storage/assets/images/FlatLogoFull.png" height="55">
<div style="padding:4px 0;font-size:18px;color:white;font-weight:300;">&copy; 2016 Build City.</div>
<div style="padding-top:5px;">
<a href="#" style="color:#30A9DE;font-size:16px;font-weight:500;">Terms of Service</a>&nbsp;&nbsp;&nbsp;
<a href="#" style="color:#30A9DE;font-size:16px;font-weight:500;">Privacy Policy</a>&nbsp;&nbsp;&nbsp;
<a href="#" style="color:#30A9DE;font-size:16px;font-weight:500;">About Us</a>&nbsp;&nbsp;&nbsp;
<a href="#" style="color:#30A9DE;font-size:16px;font-weight:500;">Jobs</a>
</div>
</div>
</div>
</div>
<div class="hiddendiv common"></div>