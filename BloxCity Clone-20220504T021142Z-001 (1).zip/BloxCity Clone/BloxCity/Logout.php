<?php
include "Header.php";
session_destroy();
header("Location: ../");
?>